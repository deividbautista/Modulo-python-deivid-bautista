from importlib.resources import path
from deividbautista.escrita import encriptar
from davidflorez.menu import menu_principal
from juanmoreno.polindromo import polindromo
from kristell.lista import agregar
import hashlib

menu_principal()